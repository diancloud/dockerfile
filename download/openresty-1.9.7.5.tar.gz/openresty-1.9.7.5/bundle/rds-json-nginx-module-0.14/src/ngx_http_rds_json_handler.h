#ifndef NGX_HTTP_RDS_JSON_HANDLER_H
#define NGX_HTTP_RDS_JSON_HANDLER_H

#include "ngx_http_rds_json_filter_module.h"

ngx_int_t ngx_http_rds_json_ret_handler(ngx_http_request_t *r);

#endif /* NGX_HTTP_RDS_JSON_HANDLER_H */

